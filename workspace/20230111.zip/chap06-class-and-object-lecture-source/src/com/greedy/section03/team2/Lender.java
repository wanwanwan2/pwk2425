package com.greedy.section03.team2;

	public class Lender {

		public void Balance(int kind) {
			// TODO Auto-generated method stub
			int balance = 100000000;
			
			if(kind ==1) {
				balance = balance-10000000;
				
			}else if(kind ==2) {
				balance = balance-20000000;

			}
			
			System.out.println("잔액은 "+balance+"입니다");
			
		}

	 }
