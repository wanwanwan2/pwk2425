package com.greedy.section01.conditional;

public class Application1 {

	public static void main(String[] args) {
		
		A_if a = new A_if();
//		a.testSimpleIfStatement();
		a.testNestedIfStatement();
		
		B_IfElse b = new B_IfElse();
//		b.testNestedIfStatement();
		b.testNestedIfStatement();
	
		C_ifElseIf c = new C_ifElseIf();
//		c.testSimpleIfElseIfStatement();
		
		D_switch d = new D_switch();
		d.testSimpleSwitchStatement();
	}
}

