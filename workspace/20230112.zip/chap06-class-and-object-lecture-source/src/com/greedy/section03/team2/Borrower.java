package com.greedy.section03.team2;


public class Borrower {
	
	public void borrow(int num) {
		// TODO Auto-generated method stub
		System.out.println(num+ "원을 빌려드렸습니다");
		
	}
	
	
	public void payback(int kind) {
		// TODO Auto-generated method stub
		
		String organ ="";
		
		if(kind ==1) {
			organ = "안구";
		}else if(kind ==2) {
			organ = "신장";
		}
		
		System.out.println(organ+ "으로 갚았습니다.");
		
	     Lender lender = new Lender();
	     
	     lender.Balance(2);
	       
		
	}

}
