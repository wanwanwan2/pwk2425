package com.greedy.section02.looping;

public class Application {

	public static void main(String[] args) {
		
		A_for a = new A_for();
//		a.testSimpleForStatement();
//		a.testForExample();
//		a.testForExample2();
		
		B_nestedFor b = new B_nestedFor();
//		b.printGugudanFromTwoToNine();
//		b.printStarInputRowTimes();
		
		C_while c = new C_while();
//		c.testWhileExample1();
		
		D_doWhile d = new D_doWhile();
//		d.testSimpleDoWhileStatement();
		d.testDoWhileExample1();
	}

}
