package com.greedy.section02.looping;

public class Applciation {
	
	public static void main(String[] args) { 
	
		A_for a = new A_for();
//		a.testSimpleForstatement();
//		a.testForExample();
//		a.testForExample2();
//		a.testForExample3();
//		a.testForExample4();
//		a.printSimpleGugudan();
		
		B_nestedFor b = new B_nestedFor();
//		b.printGugudanFromTwoToNine();
//		b.printStarInputRowTimes();
		b.printTriangleStart();
	}
}
